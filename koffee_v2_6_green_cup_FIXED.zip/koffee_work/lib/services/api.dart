import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class Api {
  static const baseUrl=String.fromEnvironment('KOFFEE_API',defaultValue:'http://10.0.2.2:8080/api');
  static String get serverBase=>baseUrl.replaceFirst(RegExp(r'/api$'),'');
  static Future<String?> token() async=>(await SharedPreferences.getInstance()).getString('token');
  static Future<Map<String,dynamic>> request(String method,String path,[Map<String,dynamic>? body]) async {
    final t=await token(); final headers={'Content-Type':'application/json',if(t!=null)'Authorization':'Bearer $t'}; final uri=Uri.parse('$baseUrl$path');
    final r=method=='GET'?await http.get(uri,headers:headers):method=='PATCH'?await http.patch(uri,headers:headers,body:jsonEncode(body??{})):await http.post(uri,headers:headers,body:jsonEncode(body??{}));
    final data=r.body.isEmpty?{}:jsonDecode(r.body); if(r.statusCode>=400)throw Exception(data['error']??'حدث خطأ'); return data is Map?Map<String,dynamic>.from(data):{'data':data};
  }
  static Future<List<dynamic>> list(String path)async{final t=await token(); final headers={'Content-Type':'application/json',if(t!=null)'Authorization':'Bearer $t'}; final r=await http.get(Uri.parse('$baseUrl$path'),headers:headers); final data=r.body.isEmpty?[]:jsonDecode(r.body); if(r.statusCode>=400) throw Exception((data is Map?data['error']:null)??'حدث خطأ'); return List<dynamic>.from(data as List);}
  static Future<void> saveAuth(Map<String,dynamic> data)async{final p=await SharedPreferences.getInstance();await p.setString('token',data['token']);}
  static Future<void> logout()async{final p=await SharedPreferences.getInstance();await p.remove('token');}
  static Future<Map<String,dynamic>> login(String u,String pw)=>request('POST','/auth/login',{'username':u,'password':pw});
  static Future<Map<String,dynamic>> register(String u,String pw,String name,{String referralCode='',List<String> faceProof=const []})=>request('POST','/auth/register',{'username':u,'password':pw,'displayName':name,'referralCode':referralCode,'faceProof':faceProof});
  static Future<Map<String,dynamic>> verifyPurchase({required String productId,String? purchaseId,required String verificationData,required String source}) => request('POST','/wallet/purchases/verify',{'productId':productId,'purchaseId':purchaseId,'verificationData':verificationData,'source':source});
  static Future<Map<String,dynamic>> roomToken(int roomId) => request('POST','/rooms/$roomId/token');
  static Future<Map<String,dynamic>> requestWithdrawal(int coins) => request('POST','/wallet/withdrawals',{'coins':coins});
  static Future<List<dynamic>> users({String query = ''}) => list('/users?search=${Uri.encodeQueryComponent(query)}');
  static Future<Map<String,dynamic>> profile(int id) => request('GET','/profile/$id');
  static Future<Map<String,dynamic>> follow(int id) => request('POST','/users/$id/follow');
  static Future<Map<String,dynamic>> toggleLike(int id) => request('POST','/posts/$id/like');
  static Future<List<dynamic>> comments(int id) => list('/posts/$id/comments');
  static Future<Map<String,dynamic>> addComment(int id,String body) => request('POST','/posts/$id/comments',{'body':body});
  static Future<List<dynamic>> profilePosts(int id) => list('/profile/$id/posts');
  static Future<Map<String,dynamic>> updateProfile({String? displayName,String? bio,String? avatarUrl}) => request('PATCH','/me',{'displayName':displayName,'bio':bio,'avatarUrl':avatarUrl});
  static Future<List<dynamic>> conversations() => list('/conversations');
  static Future<List<dynamic>> messages(int userId) => list('/messages/$userId');
  static Future<void> markMessagesRead(int userId) async => request('POST','/messages/$userId/read');
  static Future<List<dynamic>> posts({bool following = false}) => list('/posts${following ? '?feed=following' : ''}');
  static Future<List<dynamic>> notifications() => list('/notifications');
  static Future<int> unreadNotifications() async => int.tryParse('${(await request('GET','/notifications/unread-count'))['count']??0}')??0;
  static Future<void> markNotificationsRead() async => request('POST','/notifications/read');
  static Future<Map<String,dynamic>> referralStatus()=>request('GET','/referral/status');
  static Future<Map<String,dynamic>> spinReferralWheel()=>request('POST','/referral/spin');
  static Future<List<dynamic>> giftCatalog()=>list('/gifts/catalog');
  static Future<Map<String,dynamic>> sendGift({required int receiverId,required String giftId,required int coins})=>request('POST','/gifts',{'receiverId':receiverId,'giftId':giftId,'coins':coins});

  static Future<Map<String,dynamic>> uploadFile(String filePath,{String field='file'}) async {
    final t=await token(); final req=http.MultipartRequest('POST',Uri.parse('$baseUrl/upload'));
    if(t!=null) req.headers['Authorization']='Bearer $t';
    req.files.add(await http.MultipartFile.fromPath(field,filePath));
    final r=await req.send(); final text=await r.stream.bytesToString(); final data=text.isEmpty?{}:jsonDecode(text);
    if(r.statusCode>=400) throw Exception(data['error']??'تعذر رفع الملف');
    return Map<String,dynamic>.from(data);
  }
  static String mediaUrl(String? path)=>path==null||path.isEmpty?'':(path.startsWith('http')?path:'$serverBase$path');
  static Future<Map<String,dynamic>> sendMessageFile(int userId,String filePath,String body) async {
    final t=await token(); final req=http.MultipartRequest('POST',Uri.parse('$baseUrl/messages/$userId'));
    if(t!=null) req.headers['Authorization']='Bearer $t'; req.fields['body']=body; req.files.add(await http.MultipartFile.fromPath('file',filePath));
    final r=await req.send(); final text=await r.stream.bytesToString(); final data=text.isEmpty?{}:jsonDecode(text);
    if(r.statusCode>=400) throw Exception(data['error']??'تعذر إرسال الملف'); return Map<String,dynamic>.from(data);
  }

}
