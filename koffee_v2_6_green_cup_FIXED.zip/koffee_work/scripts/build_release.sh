#!/usr/bin/env bash
set -euo pipefail
flutter pub get
flutter build apk --release
printf '\nRelease APK created at: %s\n' "build/app/outputs/flutter-apk/app-release.apk"
