# Koffee — إخراج APK

## أسهل طريقة
1. ارفع المشروع إلى GitHub.
2. افتح تبويب **Actions**.
3. اختر **Build Koffee APK**.
4. اضغط **Run workflow** (أو ادفع إلى main).
5. بعد انتهاء البناء افتح نتيجة التشغيل ثم **Artifacts** وحمّل `koffee-debug-apk`.
6. فك الضغط عن الملف وثبّت `app-debug.apk` على هاتف Android.

## بناء محلي
يتطلب Flutter SDK وAndroid SDK:

```bash
flutter pub get
flutter build apk --debug
```

الملف الناتج:
`build/app/outputs/flutter-apk/app-debug.apk`

## Release
يوجد workflow منفصل لبناء `app-release.apk`. للنشر على Google Play نحتاج لاحقًا إلى إعداد توقيع Android بمفتاح keystore خاص بك، ثم بناء AAB:

```bash
flutter build appbundle --release
```

لا تضع ملف keystore أو كلمات المرور داخل GitHub أو داخل المشروع.
