import 'package:livekit_client/livekit_client.dart';
import 'api.dart';

class LiveService {
  Future<Room> joinRoom({required int roomId}) async {
    final data = await Api.roomToken(roomId);
    final room = Room();
    await room.connect(data['url'] as String, data['token'] as String);
    return room;
  }
}
