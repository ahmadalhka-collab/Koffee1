import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'api.dart';

class PurchaseService {
  PurchaseService._();
  static final instance = PurchaseService._();
  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _sub;
  final ValueNotifier<List<ProductDetails>> products = ValueNotifier([]);
  final ValueNotifier<bool> available = ValueNotifier(false);

  static const ids = <String>{
    'koffee_coins_100',
    'koffee_coins_550',
    'koffee_coins_1200',
    'koffee_coins_2500',
  };

  Future<void> initialize() async {
    available.value = await _iap.isAvailable();
    if (!available.value) return;
    _sub ??= _iap.purchaseStream.listen(_onPurchases, onError: (Object e) {
      debugPrint('IAP stream error: $e');
    });
    final response = await _iap.queryProductDetails(ids);
    if (response.error == null) products.value = response.productDetails;
  }

  Future<void> buy(ProductDetails product) async {
    final param = PurchaseParam(productDetails: product);
    await _iap.buyConsumable(purchaseParam: param, autoConsume: true);
  }

  Future<void> _onPurchases(List<PurchaseDetails> purchases) async {
    for (final purchase in purchases) {
      if (purchase.status == PurchaseStatus.purchased ||
          purchase.status == PurchaseStatus.restored) {
        try {
          await Api.verifyPurchase(
            productId: purchase.productID,
            purchaseId: purchase.purchaseID,
            verificationData: purchase.verificationData.serverVerificationData,
            source: purchase.verificationData.source,
          );
        } catch (e) {
          debugPrint('Purchase verification failed: $e');
        }
      }
      if (purchase.pendingCompletePurchase) {
        await _iap.completePurchase(purchase);
      }
    }
  }

  Future<void> dispose() async => _sub?.cancel();
}
