import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

class FaceVerificationScreen extends StatefulWidget { const FaceVerificationScreen({super.key}); @override State<FaceVerificationScreen> createState()=>_FaceVerificationScreenState(); }
class _FaceVerificationScreenState extends State<FaceVerificationScreen>{
  final picker=ImagePicker(); final detector=FaceDetector(options:FaceDetectorOptions(enableClassification:true,enableTracking:true,performanceMode:FaceDetectorMode.accurate));
  int step=0; final proof=<String>[]; bool busy=false;
  final steps=['صورة أولى: انظر للكاميرا','صورة ثانية: أدر وجهك قليلاً لليسار','صورة ثالثة: أدر وجهك قليلاً لليمين','صورة رابعة: ارمش ثم التقط الصورة'];
  Future<void> capture() async {if(busy)return;setState(()=>busy=true);try{final x=await picker.pickImage(source:ImageSource.camera,imageQuality:75,maxWidth:1280);if(x==null){setState(()=>busy=false);return;}final faces=await detector.processImage(InputImage.fromFilePath(x.path));if(faces.length!=1)throw Exception('يجب أن يظهر وجه واحد فقط أمام الكاميرا');final f=faces.first;
    if(step==1 && (f.headEulerAngleY??0)>-5)throw Exception('أدر وجهك قليلاً إلى اليسار ثم التقط الصورة');
    if(step==2 && (f.headEulerAngleY??0)<5)throw Exception('أدر وجهك قليلاً إلى اليمين ثم التقط الصورة');
    if(step==3 && f.leftEyeOpenProbability!=null && f.rightEyeOpenProbability!=null && f.leftEyeOpenProbability!>.55 && f.rightEyeOpenProbability!>.55)throw Exception('ارمش أولاً ثم التقط الصورة');
    proof.add(x.path);if(step==3){if(mounted)Navigator.pop(context,proof);}else{setState(()=>step++);}}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString().replaceFirst('Exception: ',''))));}finally{if(mounted)setState(()=>busy=false);}}
  @override void dispose(){detector.close();super.dispose();}
  @override Widget build(BuildContext c)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:const Text('التحقق من الوجه')),body:Padding(padding:const EdgeInsets.all(24),child:Column(children:[const Icon(Icons.face_retouching_natural,size:82),const SizedBox(height:20),Text('خطوة أمان لمنع الحسابات المتعددة',style:Theme.of(c).textTheme.titleLarge,textAlign:TextAlign.center),const SizedBox(height:12),Text(steps[step],style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold),textAlign:TextAlign.center),const SizedBox(height:12),Text('الخطوة ${step+1} من 4\nيجب أن يكون الوجه واضحاً، ولا تستخدم صورة أو شاشة.',textAlign:TextAlign.center),const Spacer(),SizedBox(width:double.infinity,height:54,child:FilledButton.icon(onPressed:busy?null:capture,icon:const Icon(Icons.camera_alt),label:Text(busy?'جارٍ التحقق...':'التقاط الصورة'))),const SizedBox(height:12),TextButton(onPressed:busy?null:()=>Navigator.pop(context),child:const Text('إلغاء'))]))));
}
