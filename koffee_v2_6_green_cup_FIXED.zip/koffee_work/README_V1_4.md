# #كوفي v1.4 — أول مرحلة تشغيل فعلية للواجهة

تم البدء من v1.3 وإضافة إصلاحات وتشغيل فعلي للوظائف الأساسية:

- إصلاح قراءة قوائم المنشورات والغرف من API (كانت الواجهة تتوقع List بينما طبقة API كانت تلفها داخل Map).
- ربط زر دخول الغرفة بطلب الانضمام ثم الحصول على LiveKit token.
- إضافة شاشة غرفة صوتية أولية تتصل فعلياً بـ LiveKit وتتيح كتم الميكروفون.
- إضافة شاشة محادثة فعلية: اختيار معرّف المستخدم، تحميل سجل الرسائل وإرسال الرسائل عبر API.
- رفع رقم نسخة Flutter إلى 0.4.0+3.

## ملاحظات
- لا يزال بناء APK يتطلب Flutter/Android SDK أو GitHub Actions.
- LiveKit يحتاج متغيرات البيئة على الخادم.
- شاشة المحادثة الحالية تعتمد على معرّف المستخدم، والخطوة التالية هي قائمة محادثات، تحديث لحظي عبر Socket.IO، وإشعارات.
- نظام الدفع والهدايا والسحب موجودان في الـBackend، لكن واجهات المستخدم تحتاج استكمالاً.

## v1.5 — محادثات اجتماعية لحظية
- قائمة محادثات مرتبة حسب آخر رسالة.
- بحث عن المستخدمين وبدء محادثة جديدة.
- رسائل لحظية عبر Socket.IO.
- حالة يكتب الآن.
- حالة اتصال المستخدم online/offline.
- عداد الرسائل غير المقروءة وقراءة الرسائل.
- مزامنة REST + Socket.IO لمنع تكرار الرسائل.


## v1.6 – محادثات بوسائط
- إرسال صور من المعرض داخل المحادثة.
- إرسال ملفات داخل المحادثة.
- حفظ المرفقات في الخادم وربطها بالرسالة.
- عرض الصور والملفات المرفقة ضمن فقاعات الدردشة.
- تحسين مؤشر يكتب الآن باستخدام debounce.
- دعم عرض صورة الحساب إذا كانت موجودة.
- ترقية الإصدار إلى 0.6.0+5.


## v1.7
- Public profile pages with post/follower/following counts.
- Follow/unfollow from profile.
- Profile avatar upload and editing display name/bio.
- Search results open the full public profile.
- Direct message action from public profiles.
- Backend profile statistics endpoint.


## v1.8
- Social feed with per-user like/unlike.
- Comments with real-time local refresh.
- Image posts using the existing upload service.
- Public profiles show the user's posts.
- Post cards show avatars, media, likes and comments.


## v2.3 – نظام دعوات حقيقية وعجلة الجوائز
- تُحتسب الدعوة فقط بعد إنشاء الحساب وإكمال التحقق من الوجه.
- عند الوصول إلى 31 دعوة حقيقية مكتملة، يحصل صاحب رمز الدعوة على دورة واحدة في عجلة الجوائز.
- الجوائز: 0$، 1$، 2$، 5$، 10$ بأوزان عشوائية على السيرفر.
- التحويل الافتراضي: 1$ = 100 كوينز؛ وبالتالي جائزة 10$ = 1000 كوينز.
- لا يمكن استخدام دورة العجلة أكثر من مرة للحساب نفسه.


## v2.5 security update
- Mandatory face verification before registration.
- Four-step camera challenge: frontal, left turn, right turn, blink.
- Server stores SHA-256 proof hashes and rejects exact reused proofs.
- Referral is marked verified only after face verification succeeds.
- For production-grade biometric identity matching across different photos/devices, connect a certified liveness/face-match provider; this build does not claim biometric identification.
