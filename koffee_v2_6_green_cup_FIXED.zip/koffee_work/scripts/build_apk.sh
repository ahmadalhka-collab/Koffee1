#!/usr/bin/env bash
set -euo pipefail
flutter pub get
flutter build apk --debug
printf '\nAPK created at: %s\n' "build/app/outputs/flutter-apk/app-debug.apk"
