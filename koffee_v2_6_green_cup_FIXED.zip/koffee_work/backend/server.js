import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Database from 'better-sqlite3';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { AccessToken } from 'livekit-server-sdk';

const app=express(); const httpServer=createServer(app);
const io=new Server(httpServer,{cors:{origin:'*'}});
const db=new Database(process.env.DB_PATH||'koffee.db');
const JWT_SECRET=process.env.JWT_SECRET||'CHANGE_ME_IN_PRODUCTION';
const PORT=Number(process.env.PORT||8080);
app.use(cors()); app.use(express.json({limit:'10mb'}));
fs.mkdirSync(process.env.UPLOAD_DIR||'uploads',{recursive:true});
app.use('/uploads',express.static(process.env.UPLOAD_DIR||'uploads'));

db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,display_name TEXT NOT NULL,bio TEXT DEFAULT '',avatar_url TEXT,coins INTEGER NOT NULL DEFAULT 0,earnings INTEGER NOT NULL DEFAULT 0,referral_code TEXT UNIQUE, referred_by INTEGER, referral_verified INTEGER NOT NULL DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS face_proofs(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,proof_hash TEXT UNIQUE NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS referrals(id INTEGER PRIMARY KEY AUTOINCREMENT,referrer_id INTEGER NOT NULL,referred_id INTEGER NOT NULL UNIQUE,code TEXT NOT NULL,verified INTEGER NOT NULL DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS referral_rewards(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,milestone INTEGER NOT NULL,reward_usd INTEGER NOT NULL,reward_coins INTEGER NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(user_id,milestone));
CREATE TABLE IF NOT EXISTS follows(follower_id INTEGER NOT NULL,following_id INTEGER NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(follower_id,following_id));
CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,text TEXT NOT NULL,media_url TEXT,media_type TEXT,likes INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS post_likes(post_id INTEGER NOT NULL,user_id INTEGER NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(post_id,user_id));
CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY AUTOINCREMENT,post_id INTEGER NOT NULL,user_id INTEGER NOT NULL,body TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS gifts(id INTEGER PRIMARY KEY AUTOINCREMENT,sender_id INTEGER NOT NULL,receiver_id INTEGER NOT NULL,name TEXT NOT NULL,coins INTEGER NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS wallet_transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,type TEXT NOT NULL,coins INTEGER NOT NULL,reference TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS rooms(id INTEGER PRIMARY KEY AUTOINCREMENT,host_id INTEGER NOT NULL,title TEXT NOT NULL,listeners INTEGER DEFAULT 0,live INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS room_members(room_id INTEGER NOT NULL,user_id INTEGER NOT NULL,joined_at TEXT DEFAULT CURRENT_TIMESTAMP,left_at TEXT,PRIMARY KEY(room_id,user_id));
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,sender_id INTEGER NOT NULL,receiver_id INTEGER NOT NULL,body TEXT NOT NULL,media_url TEXT,media_type TEXT,media_name TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,read_at TEXT);
CREATE TABLE IF NOT EXISTS withdrawals(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,coins INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS purchase_receipts(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,product_id TEXT NOT NULL,purchase_id TEXT,source TEXT NOT NULL,verification_data TEXT NOT NULL UNIQUE,coins INTEGER NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,type TEXT NOT NULL,actor_id INTEGER,post_id INTEGER,body TEXT NOT NULL,read_at TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS gift_bonus_claims(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,milestone INTEGER NOT NULL,period_start TEXT NOT NULL,bonus_coins INTEGER NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(user_id,milestone,period_start));`);

try { db.prepare('ALTER TABLE users ADD COLUMN referral_code TEXT').run(); } catch {}
try { db.prepare('ALTER TABLE users ADD COLUMN referred_by INTEGER').run(); } catch {}
try { db.prepare('ALTER TABLE users ADD COLUMN referral_verified INTEGER NOT NULL DEFAULT 0').run(); } catch {}
try { db.prepare('ALTER TABLE messages ADD COLUMN read_at TEXT').run(); } catch {}
try { db.prepare('ALTER TABLE messages ADD COLUMN media_url TEXT').run(); } catch {}
try { db.prepare('ALTER TABLE messages ADD COLUMN media_type TEXT').run(); } catch {}
try { db.prepare('ALTER TABLE messages ADD COLUMN media_name TEXT').run(); } catch {}

function auth(req,res,next){try{const h=req.headers.authorization||'';req.user=jwt.verify(h.replace('Bearer ','').trim(),JWT_SECRET);next();}catch{res.status(401).json({error:'غير مصرح'});}}
function token(u){return jwt.sign({id:u.id,username:u.username},JWT_SECRET,{expiresIn:'30d'});}
function publicUser(u){return {id:u.id,username:u.username,displayName:u.display_name,bio:u.bio||'',avatarUrl:u.avatar_url||null,coins:u.coins,earnings:u.earnings};}
function notify(userId,type,actorId,postId,body){if(!userId||userId===actorId)return;const i=db.prepare('INSERT INTO notifications(user_id,type,actor_id,post_id,body) VALUES(?,?,?,?,?)').run(userId,type,actorId,postId,body);const n=db.prepare(`SELECT n.id,n.type,n.actor_id AS actorId,n.post_id AS postId,n.body,n.read_at AS readAt,n.created_at AS createdAt,u.display_name AS actorName,u.username AS actorUsername,u.avatar_url AS actorAvatarUrl FROM notifications n LEFT JOIN users u ON u.id=n.actor_id WHERE n.id=?`).get(i.lastInsertRowid);io.to('user:'+userId).emit('notification:new',n);return n;}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'#كوفي',version:'2.6'}));
function makeReferralCode(username,id){return (username.replace(/[^a-z0-9]/gi,'').slice(0,5).toUpperCase()||'KOF')+String(id).padStart(5,'0');}
const REFERRAL_REWARDS_USD=[3,6,10,20,40,80,100]; const USD_TO_COINS=100;
function referralStatus(userId){const completed=db.prepare('SELECT COUNT(*) AS n FROM referrals WHERE referrer_id=? AND verified=1').get(userId).n||0;const claimed=db.prepare('SELECT milestone,reward_usd AS rewardUsd,reward_coins AS rewardCoins FROM referral_rewards WHERE user_id=? ORDER BY milestone').all(userId);const claimedSet=new Set(claimed.map(x=>x.milestone));const available=[];for(let milestone=30,idx=0;milestone<=completed;milestone+=30,idx++){if(!claimedSet.has(milestone))available.push({milestone,rewardUsd:REFERRAL_REWARDS_USD[Math.min(idx,REFERRAL_REWARDS_USD.length-1)]});}return {referralCode:db.prepare('SELECT referral_code FROM users WHERE id=?').get(userId)?.referral_code||null,completedInvites:completed,requiredInvites:30,nextMilestone:(Math.floor(completed/30)+1)*30,spinsAvailable:available.length,claimed,available};}
app.post('/api/auth/register',async(req,res)=>{const {username,password,displayName,referralCode,faceProof}=req.body||{};if(!username||!password||password.length<6)return res.status(400).json({error:'اسم المستخدم وكلمة المرور مطلوبان، وكلمة المرور 6 أحرف على الأقل'});if(!Array.isArray(faceProof)||faceProof.length<3||faceProof.length>5)return res.status(400).json({error:'التحقق من الوجه مطلوب قبل إنشاء الحساب'});try{const ref=referralCode?.trim().toUpperCase();const referrer=ref?db.prepare('SELECT id FROM users WHERE referral_code=?').get(ref):null;if(ref&&!referrer)return res.status(400).json({error:'رمز الدعوة غير صحيح'});const hashes=faceProof.map(x=>crypto.createHash('sha256').update(Buffer.from(String(x),'base64')).digest('hex'));if(new Set(hashes).size<3)return res.status(400).json({error:'صور التحقق يجب أن تكون مختلفة'});const duplicate=db.prepare(`SELECT proof_hash FROM face_proofs WHERE proof_hash IN (${hashes.map(()=>'?').join(',')}) LIMIT 1`).get(...hashes);if(duplicate)return res.status(409).json({error:'تم استخدام بيانات الوجه هذه مسبقاً لإنشاء حساب. لا يمكن إنشاء أكثر من حساب للشخص نفسه'});const hash=await bcrypt.hash(password,12);const tx=db.transaction(()=>{const i=db.prepare('INSERT INTO users(username,password_hash,display_name,referred_by,referral_verified) VALUES(?,?,?,?,?)').run(username.trim().toLowerCase(),hash,displayName?.trim()||username.trim(),referrer?.id||null,referrer?1:0);const code=makeReferralCode(username.trim().toLowerCase(),i.lastInsertRowid);db.prepare('UPDATE users SET referral_code=? WHERE id=?').run(code,i.lastInsertRowid);for(const h of hashes)db.prepare('INSERT INTO face_proofs(user_id,proof_hash) VALUES(?,?)').run(i.lastInsertRowid,h);if(referrer)db.prepare('INSERT INTO referrals(referrer_id,referred_id,code,verified) VALUES(?,?,?,1)').run(referrer.id,i.lastInsertRowid,ref);return i.lastInsertRowid;});const uid=tx();const u=db.prepare('SELECT * FROM users WHERE id=?').get(uid);res.json({token:token(u),user:publicUser(u),referralCode:u.referral_code,faceVerified:true});}catch(e){if(String(e.message).includes('UNIQUE'))return res.status(409).json({error:'اسم المستخدم أو بيانات التحقق مستخدمة مسبقاً'});res.status(400).json({error:'تعذر إنشاء الحساب'});}});
app.post('/api/auth/login',async(req,res)=>{const u=db.prepare('SELECT * FROM users WHERE username=?').get((req.body?.username||'').trim().toLowerCase());if(!u||!(await bcrypt.compare(req.body?.password||'',u.password_hash)))return res.status(401).json({error:'بيانات الدخول غير صحيحة'});res.json({token:token(u),user:publicUser(u)});});
app.get('/api/me',auth,(req,res)=>{const u=db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);res.json(publicUser(u));});
app.patch('/api/me',auth,(req,res)=>{const {displayName,bio,avatarUrl}=req.body||{};db.prepare('UPDATE users SET display_name=COALESCE(?,display_name),bio=COALESCE(?,bio),avatar_url=COALESCE(?,avatar_url) WHERE id=?').run(displayName,bio,avatarUrl,req.user.id);res.json(publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id)));});

app.get('/api/users/:username',auth,(req,res)=>{const u=db.prepare('SELECT * FROM users WHERE username=?').get(req.params.username.toLowerCase());if(!u)return res.status(404).json({error:'المستخدم غير موجود'});res.json(publicUser(u));});
app.get('/api/profile/:id',auth,(req,res)=>{
  const id=Number(req.params.id); const u=db.prepare('SELECT * FROM users WHERE id=?').get(id);
  if(!u)return res.status(404).json({error:'المستخدم غير موجود'});
  const followers=db.prepare('SELECT COUNT(*) AS n FROM follows WHERE following_id=?').get(id).n;
  const following=db.prepare('SELECT COUNT(*) AS n FROM follows WHERE follower_id=?').get(id).n;
  const posts=db.prepare('SELECT COUNT(*) AS n FROM posts WHERE user_id=?').get(id).n;
  const followingMe=!!db.prepare('SELECT 1 FROM follows WHERE follower_id=? AND following_id=?').get(req.user.id,id);
  res.json({...publicUser(u),followers,following,posts,followingMe});
});
app.post('/api/users/:id/follow',auth,(req,res)=>{const id=Number(req.params.id);if(id===req.user.id)return res.status(400).json({error:'لا يمكنك متابعة نفسك'});const exists=db.prepare('SELECT 1 FROM follows WHERE follower_id=? AND following_id=?').get(req.user.id,id);if(exists){db.prepare('DELETE FROM follows WHERE follower_id=? AND following_id=?').run(req.user.id,id);return res.json({following:false});}db.prepare('INSERT OR IGNORE INTO follows(follower_id,following_id) VALUES(?,?)').run(req.user.id,id);notify(id,'follow',req.user.id,null,'بدأ بمتابعتك');res.json({following:true});});

app.get('/api/referral/status',auth,(req,res)=>res.json(referralStatus(req.user.id)));
app.post('/api/referral/spin',auth,(req,res)=>{try{let out;db.transaction(()=>{const st=referralStatus(req.user.id);if(!st.available.length)throw new Error(`لا توجد لفة جاهزة. أكمل 30 دعوة حقيقية إضافية`);const item=st.available[0];const coins=item.rewardUsd*USD_TO_COINS;db.prepare('INSERT INTO referral_rewards(user_id,milestone,reward_usd,reward_coins) VALUES(?,?,?,?)').run(req.user.id,item.milestone,item.rewardUsd,coins);db.prepare('UPDATE users SET coins=coins+? WHERE id=?').run(coins,req.user.id);db.prepare('INSERT INTO wallet_transactions(user_id,type,coins,reference) VALUES(?,?,?,?)').run(req.user.id,'referral_wheel_reward',coins,`$${item.rewardUsd}:milestone:${item.milestone}`);out={ok:true,milestone:item.milestone,rewardUsd:item.rewardUsd,rewardCoins:coins,remaining:referralStatus(req.user.id)};})();res.json(out);}catch(e){res.status(400).json({error:e.message});}});

app.get('/api/notifications',auth,(req,res)=>res.json(db.prepare(`SELECT n.id,n.type,n.actor_id AS actorId,n.post_id AS postId,n.body,n.read_at AS readAt,n.created_at AS createdAt,u.display_name AS actorName,u.username AS actorUsername,u.avatar_url AS actorAvatarUrl FROM notifications n LEFT JOIN users u ON u.id=n.actor_id WHERE n.user_id=? ORDER BY n.id DESC LIMIT 100`).all(req.user.id)));
app.post('/api/notifications/read',auth,(req,res)=>{db.prepare('UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE user_id=? AND read_at IS NULL').run(req.user.id);res.json({ok:true});});
app.get('/api/notifications/unread-count',auth,(req,res)=>res.json({count:db.prepare('SELECT COUNT(*) AS n FROM notifications WHERE user_id=? AND read_at IS NULL').get(req.user.id).n}));

app.get('/api/posts',auth,(req,res)=>{
  const following=(req.query.feed||'').toString()==='following';
  const where=following?'WHERE p.user_id=? OR EXISTS(SELECT 1 FROM follows f WHERE f.follower_id=? AND f.following_id=p.user_id)':'';
  const args=following?[req.user.id,req.user.id,req.user.id,req.user.id]:[req.user.id];
  const order=following?'ORDER BY CASE WHEN p.user_id=? THEN 0 ELSE 1 END,p.id DESC':'ORDER BY p.id DESC';
  const sql=`SELECT p.id,p.text,p.media_url AS mediaUrl,p.media_type AS mediaType,(SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id=p.id) AS likes,EXISTS(SELECT 1 FROM post_likes pl2 WHERE pl2.post_id=p.id AND pl2.user_id=?) AS likedByMe,(SELECT COUNT(*) FROM comments c0 WHERE c0.post_id=p.id) AS commentsCount,p.created_at AS createdAt,u.id AS userId,u.display_name AS displayName,u.username,u.avatar_url AS avatarUrl FROM posts p JOIN users u ON u.id=p.user_id ${where} ${order} LIMIT 100`;
  res.json(db.prepare(sql).all(...args));
});
app.get('/api/profile/:id/posts',auth,(req,res)=>res.json(db.prepare(`SELECT p.id,p.text,p.media_url AS mediaUrl,p.media_type AS mediaType,(SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id=p.id) AS likes,EXISTS(SELECT 1 FROM post_likes pl2 WHERE pl2.post_id=p.id AND pl2.user_id=?) AS likedByMe,(SELECT COUNT(*) FROM comments c0 WHERE c0.post_id=p.id) AS commentsCount,p.created_at AS createdAt,u.id AS userId,u.display_name AS displayName,u.username,u.avatar_url AS avatarUrl FROM posts p JOIN users u ON u.id=p.user_id WHERE p.user_id=? ORDER BY p.id DESC LIMIT 100`).all(req.user.id,Number(req.params.id))));
app.post('/api/posts',auth,(req,res)=>{const {text,mediaUrl,mediaType}=req.body||{};if(!text?.trim()&&!mediaUrl)return res.status(400).json({error:'أضف نصاً أو وسائط'});const i=db.prepare('INSERT INTO posts(user_id,text,media_url,media_type) VALUES(?,?,?,?)').run(req.user.id,text?.trim()||'',mediaUrl||null,mediaType||null);res.json({id:i.lastInsertRowid});});
app.post('/api/posts/:id/like',auth,(req,res)=>{const id=Number(req.params.id);const exists=db.prepare('SELECT 1 FROM post_likes WHERE post_id=? AND user_id=?').get(id,req.user.id);if(exists)db.prepare('DELETE FROM post_likes WHERE post_id=? AND user_id=?').run(id,req.user.id);else db.prepare('INSERT OR IGNORE INTO post_likes(post_id,user_id) VALUES(?,?)').run(id,req.user.id);const likes=db.prepare('SELECT COUNT(*) AS n FROM post_likes WHERE post_id=?').get(id).n;const post=db.prepare('SELECT user_id FROM posts WHERE id=?').get(id);if(!exists&&post)notify(post.user_id,'like',req.user.id,id,'أعجب بمنشورك');res.json({liked:!exists,likes});});
app.get('/api/posts/:id/comments',auth,(req,res)=>res.json(db.prepare('SELECT c.id,c.body,c.created_at AS createdAt,u.id AS userId,u.display_name AS displayName,u.username,u.avatar_url AS avatarUrl FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=? ORDER BY c.id ASC').all(req.params.id)));
app.post('/api/posts/:id/comments',auth,(req,res)=>{const body=req.body?.body?.trim();if(!body)return res.status(400).json({error:'التعليق فارغ'});const i=db.prepare('INSERT INTO comments(post_id,user_id,body) VALUES(?,?,?)').run(req.params.id,req.user.id,body);const row=db.prepare('SELECT c.id,c.body,c.created_at AS createdAt,u.id AS userId,u.display_name AS displayName,u.username,u.avatar_url AS avatarUrl FROM comments c JOIN users u ON u.id=c.user_id WHERE c.id=?').get(i.lastInsertRowid);const post=db.prepare('SELECT user_id FROM posts WHERE id=?').get(Number(req.params.id));if(post)notify(post.user_id,'comment',req.user.id,Number(req.params.id),'علّق على منشورك');res.json(row);});

const upload=multer({storage:multer.diskStorage({destination:process.env.UPLOAD_DIR||'uploads',filename:(req,file,cb)=>cb(null,Date.now()+'-'+Math.random().toString(36).slice(2)+path.extname(file.originalname))}),limits:{fileSize:100*1024*1024}});
app.post('/api/upload',auth,upload.single('file'),(req,res)=>{if(!req.file)return res.status(400).json({error:'لم يتم اختيار ملف'});res.json({url:`/uploads/${req.file.filename}`,mimeType:req.file.mimetype,size:req.file.size});});

app.get('/api/rooms',auth,(req,res)=>res.json(db.prepare('SELECT r.id,r.title,r.listeners,r.live,r.host_id AS hostId,u.display_name AS hostName FROM rooms r JOIN users u ON u.id=r.host_id WHERE r.live=1 ORDER BY r.id DESC').all()));
app.post('/api/rooms',auth,(req,res)=>{const title=req.body?.title?.trim();if(!title)return res.status(400).json({error:'عنوان الغرفة مطلوب'});const i=db.prepare('INSERT INTO rooms(host_id,title) VALUES(?,?)').run(req.user.id,title);res.json({id:i.lastInsertRowid,title});});
app.post('/api/rooms/:id/join',auth,(req,res)=>{const id=Number(req.params.id);db.prepare('INSERT OR REPLACE INTO room_members(room_id,user_id,joined_at,left_at) VALUES(?,?,CURRENT_TIMESTAMP,NULL)').run(id,req.user.id);db.prepare('UPDATE rooms SET listeners=(SELECT COUNT(*) FROM room_members WHERE room_id=? AND left_at IS NULL) WHERE id=?').run(id,id);io.to(`room:${id}`).emit('room:presence',{roomId:id,listeners:db.prepare('SELECT listeners FROM rooms WHERE id=?').get(id)?.listeners||0});res.json({ok:true});});

app.post('/api/rooms/:id/token',auth,async(req,res)=>{const roomId=Number(req.params.id);const room=db.prepare('SELECT * FROM rooms WHERE id=? AND live=1').get(roomId);if(!room)return res.status(404).json({error:'الغرفة غير موجودة'});const url=process.env.LIVEKIT_URL,key=process.env.LIVEKIT_API_KEY,secret=process.env.LIVEKIT_API_SECRET;if(!url||!key||!secret)return res.status(503).json({error:'خدمة البث غير مهيأة بعد'});const u=db.prepare('SELECT display_name FROM users WHERE id=?').get(req.user.id);const token=new AccessToken(key,secret,{identity:String(req.user.id),name:u.display_name});token.addGrant({roomJoin:true,room:String(roomId),canPublish:true,canSubscribe:true,canPublishData:true});res.json({url,token:await token.toJwt()});});
app.post('/api/rooms/:id/leave',auth,(req,res)=>{const id=Number(req.params.id);db.prepare('UPDATE room_members SET left_at=CURRENT_TIMESTAMP WHERE room_id=? AND user_id=?').run(id,req.user.id);db.prepare('UPDATE rooms SET listeners=(SELECT COUNT(*) FROM room_members WHERE room_id=? AND left_at IS NULL) WHERE id=?').run(id,id);io.to(`room:${id}`).emit('room:presence',{roomId:id,listeners:db.prepare('SELECT listeners FROM rooms WHERE id=?').get(id)?.listeners||0});res.json({ok:true});});

// Sender loyalty bonuses: extra coins are awarded for reaching gift-sending milestones.
// Milestones reset every 24 hours to limit abuse and keep rewards predictable.
const GIFT_BONUS_MILESTONES = [
  {count: 10, bonus: 5},
  {count: 25, bonus: 15},
  {count: 50, bonus: 40},
  {count: 100, bonus: 100},
];
function currentBonusPeriod(){
  const now=new Date();
  now.setUTCHours(0,0,0,0);
  return now.toISOString();
}
function giftBonusStatus(userId){
  const period=currentBonusPeriod();
  const sent=db.prepare('SELECT COUNT(*) AS count FROM gifts WHERE sender_id=? AND created_at>=?').get(userId,period)?.count||0;
  const claimed=db.prepare('SELECT milestone,bonus_coins AS bonus FROM gift_bonus_claims WHERE user_id=? AND period_start=? ORDER BY milestone').all(userId,period);
  const claimedSet=new Set(claimed.map(x=>x.milestone));
  const available=GIFT_BONUS_MILESTONES.filter(x=>sent>=x.count&&!claimedSet.has(x.count));
  return {periodStart:period,giftsSent:sent,milestones:GIFT_BONUS_MILESTONES.map(x=>({...x,claimed:claimedSet.has(x.count),available:sent>=x.count&&!claimedSet.has(x.count)})),availableBonus:available.reduce((n,x)=>n+x.bonus,0)};
}
const GIFT_CATALOG = [
  {id:'popular_rose',category:'popular',name:'وردة',coins:2000,icon:'🌹',effect:'petals'},
  {id:'popular_heart',category:'popular',name:'قلب الحب',coins:5000,icon:'💖',effect:'hearts'},
  {id:'popular_party',category:'popular',name:'احتفال',coins:10000,icon:'🎉',effect:'confetti'},
  {id:'popular_crown',category:'popular',name:'التاج',coins:25000,icon:'👑',effect:'crown'},
  {id:'popular_diamond',category:'popular',name:'ألماسة',coins:50000,icon:'💎',effect:'sparkle'},
  {id:'popular_flame',category:'popular',name:'اللهب',coins:75000,icon:'🔥',effect:'flame'},
  {id:'popular_rocket',category:'popular',name:'الصاروخ',coins:100000,icon:'🚀',effect:'rocket'},
  {id:'popular_lion',category:'popular',name:'الأسد',coins:150000,icon:'🦁',effect:'lion'},
  {id:'popular_dragon',category:'popular',name:'التنين',coins:200000,icon:'🐉',effect:'dragon'},
  {id:'popular_legend',category:'popular',name:'الأسطورة',coins:300000,icon:'👑✨',effect:'legend'},
  {id:'luck_clover',category:'luck',name:'حظ صغير',coins:100,icon:'🍀',effect:'luck'},
  {id:'luck_star',category:'luck',name:'نجمة الحظ',coins:250,icon:'🌟',effect:'luck'},
  {id:'luck_rose',category:'luck',name:'وردة الحظ',coins:500,icon:'🌹',effect:'luck'},
  {id:'luck_gem',category:'luck',name:'جوهرة الحظ',coins:1000,icon:'💎',effect:'luck'},
  {id:'luck_box',category:'luck',name:'صندوق الحظ',coins:2500,icon:'🧧',effect:'luck'},
  {id:'luck_jackpot',category:'luck',name:'جاكبوت الحظ',coins:5000,icon:'🎰',effect:'jackpot'},
  {id:'luck_king',category:'luck',name:'ملك الحظ',coins:7500,icon:'👑',effect:'luck'},
  {id:'luck_big',category:'luck',name:'الحظ الكبير',coins:10000,icon:'💰',effect:'jackpot'},
];
app.get('/api/gifts/catalog',auth,(req,res)=>res.json(GIFT_CATALOG));

app.post('/api/gifts',auth,(req,res)=>{const receiverId=Number(req.body?.receiverId),value=Number(req.body?.coins);const giftId=req.body?.giftId?.toString();const catalogGift=GIFT_CATALOG.find(g=>g.id===giftId&&g.coins===value);if(!receiverId||!value||value<1||!catalogGift)return res.status(400).json({error:'الهدية غير صحيحة'});if(receiverId===req.user.id)return res.status(400).json({error:'لا يمكنك إرسال هدية لنفسك'});try{let bonusAwarded=0;db.transaction(()=>{const sender=db.prepare('SELECT coins FROM users WHERE id=?').get(req.user.id);if(!sender||sender.coins<value)throw new Error('رصيد العملات غير كافٍ');if(!db.prepare('SELECT id FROM users WHERE id=?').get(receiverId))throw new Error('المستخدم غير موجود');db.prepare('UPDATE users SET coins=coins-? WHERE id=?').run(value,req.user.id);db.prepare('UPDATE users SET earnings=earnings+? WHERE id=?').run(value,receiverId);db.prepare('INSERT INTO gifts(sender_id,receiver_id,name,coins) VALUES(?,?,?,?)').run(req.user.id,receiverId,catalogGift.name,value);db.prepare('INSERT INTO wallet_transactions(user_id,type,coins,reference) VALUES(?,?,?,?)').run(req.user.id,'gift_sent',-value,String(receiverId));db.prepare('INSERT INTO wallet_transactions(user_id,type,coins,reference) VALUES(?,?,?,?)').run(receiverId,'gift_received',value,String(req.user.id));
  const status=giftBonusStatus(req.user.id);
  const period=status.periodStart;
  for(const milestone of status.milestones.filter(x=>x.available)){
    db.prepare('INSERT OR IGNORE INTO gift_bonus_claims(user_id,milestone,period_start,bonus_coins) VALUES(?,?,?,?)').run(req.user.id,milestone.count,period,milestone.bonus);
    const inserted=db.prepare('SELECT changes() AS c').get().c;
    if(inserted){ bonusAwarded+=milestone.bonus; db.prepare('UPDATE users SET coins=coins+? WHERE id=?').run(milestone.bonus,req.user.id); db.prepare('INSERT INTO wallet_transactions(user_id,type,coins,reference) VALUES(?,?,?,?)').run(req.user.id,'gift_sender_bonus',milestone.bonus,`milestone:${milestone.count}`); }
  }
})();res.json({ok:true,bonusAwarded,bonus:giftBonusStatus(req.user.id)});}catch(e){res.status(400).json({error:e.message});}});
app.get('/api/gifts/bonus-status',auth,(req,res)=>res.json(giftBonusStatus(req.user.id)));
app.get('/api/wallet/transactions',auth,(req,res)=>res.json(db.prepare('SELECT id,type,coins,reference,created_at AS createdAt FROM wallet_transactions WHERE user_id=? ORDER BY id DESC LIMIT 100').all(req.user.id)));
const coinProducts = {koffee_coins_100:100,koffee_coins_550:550,koffee_coins_1200:1200,koffee_coins_2500:2500};
app.post('/api/wallet/purchases/verify',auth,(req,res)=>{
  const {productId,purchaseId,verificationData,source}=req.body||{}; const coins=coinProducts[productId];
  if(!coins||!verificationData||!source)return res.status(400).json({error:'إيصال الشراء غير مكتمل'});
  try{db.transaction(()=>{const prior=db.prepare('SELECT id FROM purchase_receipts WHERE verification_data=?').get(verificationData);if(prior)return;db.prepare('INSERT INTO purchase_receipts(user_id,product_id,purchase_id,source,verification_data,coins) VALUES(?,?,?,?,?,?)').run(req.user.id,productId,purchaseId||null,source,verificationData,coins);db.prepare('UPDATE users SET coins=coins+? WHERE id=?').run(coins,req.user.id);db.prepare('INSERT INTO wallet_transactions(user_id,type,coins,reference) VALUES(?,?,?,?)').run(req.user.id,'purchase',coins,productId);})();res.json(publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id)));}catch{res.status(400).json({error:'تعذر تثبيت عملية الشراء'});}
});
app.post('/api/wallet/withdrawals',auth,(req,res)=>{const coins=Math.floor(Number(req.body?.coins)||0);if(coins<100)return res.status(400).json({error:'الحد الأدنى للسحب 100 عملة'});try{db.transaction(()=>{const u=db.prepare('SELECT earnings FROM users WHERE id=?').get(req.user.id);if(!u||u.earnings<coins)throw new Error('الرصيد غير كافٍ');db.prepare('UPDATE users SET earnings=earnings-? WHERE id=?').run(coins,req.user.id);db.prepare('INSERT INTO withdrawals(user_id,coins) VALUES(?,?)').run(req.user.id,coins);db.prepare('INSERT INTO wallet_transactions(user_id,type,coins,reference) VALUES(?,?,?,?)').run(req.user.id,'withdrawal',-coins,'pending');})();res.json({ok:true,status:'pending'});}catch(e){res.status(400).json({error:e.message});}});
app.get('/api/wallet/withdrawals',auth,(req,res)=>res.json(db.prepare('SELECT id,coins,status,created_at AS createdAt FROM withdrawals WHERE user_id=? ORDER BY id DESC LIMIT 50').all(req.user.id)));

app.post('/api/wallet/dev-credit',auth,(req,res)=>{const amount=Math.floor(Number(req.body?.coins)||0);if(amount<1)return res.status(400).json({error:'المبلغ غير صحيح'});db.transaction(()=>{db.prepare('UPDATE users SET coins=coins+? WHERE id=?').run(amount,req.user.id);db.prepare('INSERT INTO wallet_transactions(user_id,type,coins,reference) VALUES(?,?,?,?)').run(req.user.id,'dev_credit',amount,'test');})();res.json(publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id)));});

app.get('/api/users',auth,(req,res)=>{
  const q=(req.query.search||'').toString().trim().toLowerCase();
  const rows=q
    ? db.prepare(`SELECT id,username,display_name AS displayName,bio,avatar_url AS avatarUrl FROM users WHERE id<>? AND (LOWER(username) LIKE ? OR LOWER(display_name) LIKE ?) ORDER BY display_name LIMIT 50`).all(req.user.id,`%${q}%`,`%${q}%`)
    : db.prepare(`SELECT id,username,display_name AS displayName,bio,avatar_url AS avatarUrl FROM users WHERE id<>? ORDER BY id DESC LIMIT 50`).all(req.user.id);
  res.json(rows);
});

app.get('/api/conversations',auth,(req,res)=>{
  const sql=`SELECT u.id,u.username,u.display_name AS displayName,u.bio,u.avatar_url AS avatarUrl,
    lm.body AS lastMessage,lm.created_at AS lastMessageAt,lm.sender_id AS lastSenderId,
    COALESCE(un.unreadCount,0) AS unreadCount
    FROM users u
    JOIN (SELECT CASE WHEN sender_id=? THEN receiver_id ELSE sender_id END AS other_id, MAX(id) AS last_id
          FROM messages WHERE sender_id=? OR receiver_id=? GROUP BY other_id) x ON x.other_id=u.id
    JOIN messages lm ON lm.id=x.last_id
    LEFT JOIN (SELECT sender_id AS other_id,COUNT(*) AS unreadCount FROM messages WHERE receiver_id=? AND read_at IS NULL GROUP BY sender_id) un ON un.other_id=u.id
    ORDER BY lm.id DESC`;
  res.json(db.prepare(sql).all(req.user.id,req.user.id,req.user.id,req.user.id));
});

app.get('/api/messages/:userId',auth,(req,res)=>res.json(db.prepare('SELECT m.id,m.body,m.media_url AS mediaUrl,m.media_type AS mediaType,m.media_name AS mediaName,m.created_at AS createdAt,m.read_at AS readAt,u.id AS senderId,u.display_name AS senderName FROM messages m JOIN users u ON u.id=m.sender_id WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) ORDER BY m.id ASC').all(req.user.id,req.params.userId,req.params.userId,req.user.id)));
app.post('/api/messages/:userId/read',auth,(req,res)=>{const senderId=Number(req.params.userId);db.prepare('UPDATE messages SET read_at=CURRENT_TIMESTAMP WHERE sender_id=? AND receiver_id=? AND read_at IS NULL').run(senderId,req.user.id);io.to(`user:${senderId}`).emit('message:read',{userId:req.user.id});res.json({ok:true});});
app.post('/api/messages/:userId',auth,upload.single('file'),(req,res)=>{
  const body=(req.body?.body||'').trim(); const receiverId=Number(req.params.userId);
  if(!body && !req.file)return res.status(400).json({error:'الرسالة فارغة'});
  if(receiverId===req.user.id)return res.status(400).json({error:'لا يمكنك مراسلة نفسك'});
  const mediaUrl=req.file?`/uploads/${req.file.filename}`:null; const mediaType=req.file?.mimetype||null; const mediaName=req.file?.originalname||null;
  const i=db.prepare('INSERT INTO messages(sender_id,receiver_id,body,media_url,media_type,media_name) VALUES(?,?,?,?,?,?)').run(req.user.id,receiverId,body||'',mediaUrl,mediaType,mediaName);
  const msg={id:Number(i.lastInsertRowid),body:body||'',mediaUrl,mediaType,mediaName,senderId:req.user.id,receiverId,createdAt:new Date().toISOString(),readAt:null};
  io.to(`user:${receiverId}`).emit('message:new',msg); io.to(`user:${req.user.id}`).emit('message:new',msg); res.json(msg);
});

httpServer.listen(PORT,()=>console.log(`#كوفي backend running on ${PORT}`));
