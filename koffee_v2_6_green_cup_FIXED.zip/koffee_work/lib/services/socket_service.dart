import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'api.dart';

typedef SocketHandler = void Function(dynamic data);

class KoffeeSocket {
  IO.Socket? _socket;
  final Map<String, List<SocketHandler>> _handlers = {};

  Future<void> connect() async {
    if (_socket?.connected == true) return;
    final token = await Api.token();
    if (token == null) return;
    final socket = IO.io(Api.serverBase, IO.OptionBuilder()
        .setTransports(['websocket'])
        .setAuth({'token': token})
        .disableAutoConnect()
        .build());
    _socket = socket;
    socket.onConnect((_) => _emitLocal('connected', true));
    socket.onDisconnect((_) => _emitLocal('disconnected', true));
    socket.on('message:new', (data) => _emitLocal('message:new', data));
    socket.on('message:read', (data) => _emitLocal('message:read', data));
    socket.on('user:presence', (data) => _emitLocal('user:presence', data));
    socket.on('typing:start', (data) => _emitLocal('typing:start', data));
    socket.on('typing:stop', (data) => _emitLocal('typing:stop', data));
    socket.connect();
  }

  void on(String event, SocketHandler handler) {
    (_handlers[event] ??= []).add(handler);
  }

  void off(String event, SocketHandler handler) {
    _handlers[event]?.remove(handler);
  }

  void _emitLocal(String event, dynamic data) {
    for (final h in List<SocketHandler>.from(_handlers[event] ?? const [])) {
      h(data);
    }
  }

  void sendMessage(int receiverId, String body) {
    _socket?.emit('message:send', {'receiverId': receiverId, 'body': body});
  }

  void typing(int receiverId, bool active) {
    _socket?.emit(active ? 'typing:start' : 'typing:stop', {'receiverId': receiverId});
  }

  void read(int senderId) {
    _socket?.emit('message:read', {'senderId': senderId});
  }

  void disconnect() {
    _socket?.disconnect();
    _socket = null;
  }
}
