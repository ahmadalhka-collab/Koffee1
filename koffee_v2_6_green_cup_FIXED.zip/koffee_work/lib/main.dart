import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/auth_screen.dart';
import 'services/api.dart';

void main() {
  runApp(const KoffeeApp());
}

class KoffeeApp extends StatelessWidget {
  const KoffeeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '#كوفي',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF0B7A3B),
        scaffoldBackgroundColor: const Color(0xFFF8F5F2),
      ),
      home: const Startup(),
    );
  }
}

class Startup extends StatelessWidget { const Startup({super.key}); @override Widget build(BuildContext context)=>FutureBuilder<String?>(future:Api.token(),builder:(c,s)=>s.connectionState!=ConnectionState.done?const Scaffold(body:Center(child:CircularProgressIndicator())):s.data==null?const AuthScreen():const HomeScreen()); }
